package br.gov.sp.cps.projMegaSena

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val bSorteio = findViewById<Button>(R.id.bSorteio)
        val bLimpar = findViewById<Button>(R.id.bLimpar)

        val n1 = findViewById<TextView>(R.id.n1)
        val n2 = findViewById<TextView>(R.id.n2)
        val n3 = findViewById<TextView>(R.id.n3)
        val n4 = findViewById<TextView>(R.id.n4)
        val n5 = findViewById<TextView>(R.id.n5)
        val n6 = findViewById<TextView>(R.id.n6)

        bSorteio.setOnClickListener {

            val numeros = mutableSetOf<Int>()

            while (numeros.size < 6) {
                numeros.add((1..60).random())
            }

            val lista = numeros.toList().sorted()

            n1.text = lista[0].toString()
            n2.text = lista[1].toString()
            n3.text = lista[2].toString()
            n4.text = lista[3].toString()
            n5.text = lista[4].toString()
            n6.text = lista[5].toString()
        }

        bLimpar.setOnClickListener {
            n1.text = ""
            n2.text = ""
            n3.text = ""
            n4.text = ""
            n5.text = ""
            n6.text = ""
        }
    }
}