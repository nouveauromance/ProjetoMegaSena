# Projeto Mega Sena (fevereiro/2026)

🔎 Este repositório contém a atividade desenvolvida para a disciplina de Programação para Dispositivos Móveis. O projeto
consiste na elaboração de um sistema mobile que simula um sorteio de loteria, selecionando 6 números (de 1 a 60) e mostrando os resultados na tela
(sem repetir os números), acompanhados de um botão para limpar e outro para realizar o sorteio.

## Instalação

📌 Instale o projeto com npm:

```bash
  npm install ProjMegaSena
  cd ProjMegaSena
```
    
## Autores

- [@Natali](https://github.com/nouveauromance)

🔗 Aula por Vinícius Heltai Pacheco

📍 Fatec Diadema Luigi Papaiz 
